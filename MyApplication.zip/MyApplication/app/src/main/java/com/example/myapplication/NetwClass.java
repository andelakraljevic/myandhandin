package com.example.myapplication;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;


//MY MAIN NETWORKING CLASS
public class NetwClass extends AppCompatActivity {

    ImageView kbhimage;
    ImageView aaimage;
    public static TextView datakbh;
    public static TextView dataaa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.net_layout);

        kbhimage = (ImageView) findViewById(R.id.about_image1);
        aaimage = (ImageView) findViewById(R.id.about_image2);
        datakbh = (TextView) findViewById(R.id.fetcheddata1);
        dataaa = (TextView) findViewById(R.id.fetcheddata2);

        FetchedData process = new FetchedData();
        process.execute();


    }
}


