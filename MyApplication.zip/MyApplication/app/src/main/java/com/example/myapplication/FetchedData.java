package com.example.myapplication;

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class FetchedData extends AsyncTask<Void, Void, Void> {
    String data1 = "";
    String dataParsed1 = "";
    String singleParsed1 = "";

    String data2 = "";
    String dataParsed2 = "";
    String singleParsed2 = "";

    @Override
    protected Void doInBackground(Void... voids) {


        try {
            URL url1 = new URL("https://api.myjson.com/bins/6sqs4");
            HttpURLConnection httpURLConnection1 = (HttpURLConnection) url1.openConnection();
            InputStream inputStream1 = httpURLConnection1.getInputStream();
            BufferedReader bufferedReader1 = new BufferedReader(new InputStreamReader(inputStream1));
            String line1 = "";
            while (line1 != null) {
                line1 = bufferedReader1.readLine();
                data1 = data1 + line1;
            }
            JSONArray JA = new JSONArray(data1);
            for (int i = 0; i < JA.length(); i++) {
                JSONObject JO = (JSONObject) JA.get(i);


                singleParsed1 = "Location: " + JO.get("location") + "\n" +
                        "Address: " + JO.get("address") + "\n" +
                        "Email: " + JO.get("email") + "\n" +
                        "Phone number: " + JO.get("phone") + "\n";

                dataParsed1 = dataParsed1 + singleParsed1 + "\n";


            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            URL url2 = new URL("https://api.myjson.com/bins/jauhg");
            HttpURLConnection httpURLConnection2 = (HttpURLConnection) url2.openConnection();
            InputStream inputStream2 = httpURLConnection2.getInputStream();
            BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(inputStream2));
            String line2 = "";
            while (line2 != null) {
                line2 = bufferedReader2.readLine();
                data2 = data2 + line2;
            }
            JSONArray JA = new JSONArray(data2);
            for (int i = 0; i < JA.length(); i++) {
                JSONObject JO = (JSONObject) JA.get(i);


                singleParsed2 = "Location: " + JO.get("location") + "\n" +
                        "Address: " + JO.get("address") + "\n" +
                        "Email: " + JO.get("email") + "\n" +
                        "Phone number: " + JO.get("phone") + "\n";

                dataParsed2 = dataParsed2 + singleParsed2 + "\n";


            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }


        return null;
    }


    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);

        NetwClass.datakbh.setText(this.dataParsed1);
        NetwClass.dataaa.setText(this.dataParsed2);
    }
}


