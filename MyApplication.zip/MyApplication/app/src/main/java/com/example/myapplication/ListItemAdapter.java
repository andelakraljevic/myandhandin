package com.example.myapplication;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ListItemAdapter extends RecyclerView.Adapter<ListItemAdapter.ViewHolder> {


    private ArrayList<MyListItem> mListItems;
    final private OnListItemClickListener mOnListItemClickListener;
    // sparse boolean array for checking the state of the items
    private SparseBooleanArray itemStateArray = new SparseBooleanArray();


    ListItemAdapter(ArrayList<MyListItem> items, OnListItemClickListener listener) {
        mListItems = items;
        mOnListItemClickListener = listener;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListItemAdapter.ViewHolder viewHolder, int position) {

        viewHolder.icon.setImageResource(mListItems.get(position).getIconId());
        viewHolder.name.setText(mListItems.get(position).getName());
        viewHolder.bind(position);


        viewHolder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int index = viewHolder.getAdapterPosition();
                String print = mListItems.get(index).getName();

                if (viewHolder.checkBox.isChecked()) {
                    Snackbar.make(v, print + " added.", Snackbar.LENGTH_SHORT).show();
                } else if (!(viewHolder.checkBox.isChecked())) {
                    Snackbar.make(v, print + " removed.", Snackbar.LENGTH_SHORT).show();
                }

            }
        });
    }

    public int getItemCount() {
        return mListItems.size();
    }


    //-------------------------------------------------------------------
//VIEW HOLDER CLASS
    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView name;
        ImageView icon;
        CheckBox checkBox;
        Context context;

        ViewHolder(View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.iv_icon);
            name = itemView.findViewById(R.id.tv_name);
            checkBox = (CheckBox) itemView.findViewById(R.id.checkbox);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            mOnListItemClickListener.onListItemClick(getAdapterPosition());

            int adapterPosition = getAdapterPosition();
            if (!itemStateArray.get(adapterPosition, false)) {
                checkBox.setChecked(true);
                itemStateArray.put(adapterPosition, true);
            } else {
                checkBox.setChecked(false);
                itemStateArray.put(adapterPosition, false);
            }

        }

        public void bind(int position) {
            // use the sparse boolean array to check
            if (!itemStateArray.get(position, false)) {
                checkBox.setChecked(false);
            } else {
                checkBox.setChecked(true);
            }
        }
    }

    public interface OnListItemClickListener {
        void onListItemClick(int clickedItemIndex);
    }
}