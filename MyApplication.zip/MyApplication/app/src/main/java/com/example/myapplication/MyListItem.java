package com.example.myapplication;

public class MyListItem {


    private String mName;
    private int mIconId;


    MyListItem(String name, int iconId) {
        mName = name;
        mIconId = iconId;
    }


    public String getName() {
        return mName;
    }


    public int getIconId() {
        return mIconId;
    }


}

