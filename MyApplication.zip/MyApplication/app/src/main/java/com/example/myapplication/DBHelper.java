package com.example.myapplication;


import java.util.ArrayList;
import java.util.HashMap;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;


//Database Helper class
public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "MyDBName.db";
    public static final String CUSTOMERINFO_TABLE_NAME = "customerInfo";
    public static final String CUSTOMERINFO_COLUMN_ID = "id";
    public static final String CUSTOMERINFO_COLUMN_NAME = "name";
    public static final String CUSTOMERINFO_COLUMN_EMAIL = "email";
    public static final String CUSTOMERINFO_COLUMN_PHONENUMBER = "phoneNumber";
    public static final String CUSTOMERINFO_COLUMN_CITY = "city";
    public static final String CUSTOMERINFO_COLUMN_AGE = "age";
    private HashMap hp;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL(
                "CREATE TABLE " + CUSTOMERINFO_TABLE_NAME + "(" +
                        CUSTOMERINFO_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                        CUSTOMERINFO_COLUMN_NAME + " text," +
                        CUSTOMERINFO_COLUMN_EMAIL + " text," +
                        CUSTOMERINFO_COLUMN_PHONENUMBER + " text," +
                        CUSTOMERINFO_COLUMN_CITY + " text," +
                        CUSTOMERINFO_COLUMN_AGE + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS customerInfo");
        onCreate(db);
    }

    public boolean insertCustomer(String name, String email, String phone, String city, String age) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("email", email);
        contentValues.put("phone", phone);
        contentValues.put("city", city);
        contentValues.put("age", age);
        db.insert("customerInfo", null, contentValues);
        return true;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from customerInfo where id=" + id + "", null);
        return res;
    }

    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, CUSTOMERINFO_TABLE_NAME);
        return numRows;
    }

    public boolean updateCustomer(Integer id, String name, String email, String phone, String city, String age) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("email", email);
        contentValues.put("phone", phone);
        contentValues.put("city", city);
        contentValues.put("age", age);
        db.update("customerInfo", contentValues, "id = ? ", new String[]{Integer.toString(id)});
        return true;
    }

    public Integer deleteCustomer(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("customerInfo",
                "id = ? ",
                new String[]{Integer.toString(id)});
    }

    public ArrayList<String> getAllCustomers() {
        ArrayList<String> array_list = new ArrayList<String>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from customerInfo", null);
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex(CUSTOMERINFO_COLUMN_NAME)));
            res.moveToNext();
        }
        return array_list;
    }


    public boolean addData(String name, String email, String phone, String city, String age) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(CUSTOMERINFO_COLUMN_NAME, name);
        contentValues.put(CUSTOMERINFO_COLUMN_EMAIL, email);
        contentValues.put(CUSTOMERINFO_COLUMN_PHONENUMBER, phone);
        contentValues.put(CUSTOMERINFO_COLUMN_CITY, city);
        contentValues.put(CUSTOMERINFO_COLUMN_AGE, age);

        long result = db.insert(CUSTOMERINFO_TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
}