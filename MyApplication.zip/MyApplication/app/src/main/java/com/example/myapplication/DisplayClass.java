package com.example.myapplication;

//This class is the one that asks a customer
//for information and stores that information in the database.

import android.os.Bundle;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class DisplayClass extends AppCompatActivity {

    DBHelper mydb;

    TextView name;
    TextView email;
    TextView phone;
    TextView city;
    TextView age;
    int id_To_Update = 0;
    Button sendButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_class);
        mydb = new DBHelper(this);
        name = (TextView) findViewById(R.id.editTextName);
        email = (TextView) findViewById(R.id.editTextEmail);
        phone = (TextView) findViewById(R.id.editTextPhone);
        city = (TextView) findViewById(R.id.editTextCity);
        age = (TextView) findViewById(R.id.editTextAge);
        sendButton = (Button) findViewById(R.id.buttonSend);


        addData();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            int Value = extras.getInt("id");

            if (Value > 0) {
                //means this is the view part not the add contact part.
                Cursor rs = mydb.getData(Value);
                id_To_Update = Value;
                rs.moveToFirst();

                String nam = rs.getString(rs.getColumnIndex(DBHelper.CUSTOMERINFO_COLUMN_NAME));
                String emai = rs.getString(rs.getColumnIndex(DBHelper.CUSTOMERINFO_COLUMN_EMAIL));
                String phon = rs.getString(rs.getColumnIndex(DBHelper.CUSTOMERINFO_COLUMN_PHONENUMBER));
                String cit = rs.getString(rs.getColumnIndex(DBHelper.CUSTOMERINFO_COLUMN_CITY));
                String ag = rs.getString(rs.getColumnIndex(DBHelper.CUSTOMERINFO_COLUMN_CITY));

                if (!rs.isClosed()) {
                    rs.close();
                }

                sendButton.setVisibility(View.INVISIBLE);

                name.setText((CharSequence) nam);
                name.setFocusable(false);
                name.setClickable(false);

                email.setText((CharSequence) emai);
                email.setFocusable(false);
                email.setClickable(false);

                phone.setText((CharSequence) phon);
                phone.setFocusable(false);
                phone.setClickable(false);


                city.setText((CharSequence) cit);
                city.setFocusable(false);
                city.setClickable(false);

                age.setText((CharSequence) ag);
                age.setFocusable(false);
                age.setClickable(false);
            }
        }
    }


    public void run(View view) {
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            int Value = extras.getInt("id");
            if (Value > 0) {
                if (mydb.updateCustomer(id_To_Update, name.getText().toString(),
                        email.getText().toString(), phone.getText().toString(),
                        city.getText().toString(), age.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "Updated", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "not Updated", Toast.LENGTH_SHORT).show();
                }
            } else {
                if (mydb.insertCustomer(name.getText().toString(), email.getText().toString(), phone.getText().toString(),
                        city.getText().toString(), age.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "done",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "not done",
                            Toast.LENGTH_SHORT).show();
                }
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        }
    }


    public void addData() {
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameString = name.getText().toString();
                if (nameString.trim().equals("")) {
                    Toast.makeText(DisplayClass.this, "Name field cannot be empty.", Toast.LENGTH_SHORT).show();
                    return;
                }
                String emailString = email.getText().toString();

                if (emailString.trim().equals("")) {
                    Toast.makeText(DisplayClass.this, "Email field cannot be empty.", Toast.LENGTH_SHORT).show();
                    return;
                }
                String phoneString = phone.getText().toString();
                if (phoneString.trim().equals("")) {
                    Toast.makeText(DisplayClass.this, "Phone field cannot be empty.", Toast.LENGTH_SHORT).show();
                    return;
                }
                String cityString = city.getText().toString();
                if (cityString.trim().equals("")) {
                    Toast.makeText(DisplayClass.this, "City field cannot be empty.", Toast.LENGTH_SHORT).show();
                    return;
                }
                String ageString = age.getText().toString();
                if (ageString.trim().equals("")) {
                    Toast.makeText(DisplayClass.this, "Age field cannot be empty.", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean insertData = mydb.addData(nameString, emailString, phoneString, cityString, ageString);


                if (insertData == true) {
                    Toast.makeText(DisplayClass.this, "Order sent!", Toast.LENGTH_SHORT).show();
                    openHomeAgain();
                } else {
                    Toast.makeText(DisplayClass.this, "Something went wrong.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    public void openHomeAgain() {
        Intent inte = new Intent(this, Home.class);
        startActivity(inte);
    }

}

