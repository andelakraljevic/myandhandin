package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;

public class FragmentFruit extends Fragment implements ListItemAdapter.OnListItemClickListener {

    RecyclerView myRV;
    RecyclerView.Adapter myListItemAdapter;
    Button fab_frag;

    public FragmentFruit() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_layout,
                container, false);

        myRV = (RecyclerView) view.findViewById(R.id.myRV);
        fab_frag = (Button) view.findViewById(R.id.Buttonfragment);

        ArrayList<MyListItem> items = new ArrayList<>();
        items.add(new MyListItem("Apple", R.drawable.fruit_apple));
        items.add(new MyListItem("Blueberry", R.drawable.fruit_blueb));
        items.add(new MyListItem("Grapefruit", R.drawable.fruit_grapefruit));
        items.add(new MyListItem("Kiwi", R.drawable.fruit_kiwi));
        items.add(new MyListItem("Mango", R.drawable.fruit_mango));
        items.add(new MyListItem("Pineapple", R.drawable.fruit_pineapple));


        myListItemAdapter = new ListItemAdapter(items, this);
        myRV.setAdapter(myListItemAdapter);
        GridLayoutManager gridlayoutManager = new GridLayoutManager(getActivity(), 2);
        myRV.setLayoutManager(gridlayoutManager);

        fab_frag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityInfo();
            }
        });
        return view;
    }

    @Override
    public void onListItemClick(int clickedItemIndex) {

    }

    private void startActivityInfo() {
        Intent intentx = new Intent(getActivity(), DisplayClass.class);
        startActivity(intentx);

    }
}
