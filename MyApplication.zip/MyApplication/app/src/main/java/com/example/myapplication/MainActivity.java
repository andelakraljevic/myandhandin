package com.example.myapplication;

import android.content.Intent;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private AppBarLayout appBarLayout;
    private ViewPager viewPager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tabLayout = findViewById(R.id.tabLayout);
        appBarLayout = (AppBarLayout) findViewById(R.id.appbar);
        viewPager = findViewById(R.id.viewPager);
        PagerAdapter pagerAdapter = new FixedTabsPagerAdapter(getSupportFragmentManager());

        ((FixedTabsPagerAdapter) pagerAdapter).addFragments(new FragmentVegetables(), "Vegetables");
        ((FixedTabsPagerAdapter) pagerAdapter).addFragments(new FragmentFish(), "Fish");
        ((FixedTabsPagerAdapter) pagerAdapter).addFragments(new FragmentMeat(), "Meat");
        ((FixedTabsPagerAdapter) pagerAdapter).addFragments(new FragmentFruit(), "Fruit");
        ((FixedTabsPagerAdapter) pagerAdapter).addFragments(new FragmentSeeds(), "Seeds & Nuts");
        ((FixedTabsPagerAdapter) pagerAdapter).addFragments(new FragmentDressing(), "Dressing");
        ((FixedTabsPagerAdapter) pagerAdapter).addFragments(new FragmentOil(), "Oil");
        viewPager.setAdapter(pagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
    }


}
