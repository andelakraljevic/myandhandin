package com.example.myapplication;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class Home extends AppCompatActivity {


    Button border;
    Button babout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_layout);


        border = (Button) findViewById(R.id.button_order);
        babout = (Button) findViewById(R.id.button_about);

        border.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityOrdering();
            }
        });

        babout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityAbout();

            }
        });

    }

    private void startActivityOrdering() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }

    private void startActivityAbout() {
        Intent intent = new Intent(this, NetwClass.class);
        startActivity(intent);

    }
}
